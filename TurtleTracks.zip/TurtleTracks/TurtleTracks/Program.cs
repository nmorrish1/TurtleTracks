using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TurtleTracks
{
    class Program
    {
        /// <summary>
        /// A simple program that takes in a set of directions to give to a turtle walking along a grid
        /// Prompts the user to give a file name and file path
        /// Valid inputs from a text file (no spaces) are:
        ///     F -> move forward one
        ///     R -> rotate right
        ///     L -> rotate left
        /// </summary>
        static void Main(string[] args)
        {
            bool waitingForFile = true;
            string logUnique = "Y";
            string defaultFileName = "directions.txt";
            string fileName;
            string filePath = null;
            List<char> directionsList = new List<char>();

            //turtle starts travel in the positive y direction.
            int[] currentXY = new int[] { 0, 0 };
            int[] travelVectorXY = new int[] { 0, 1 };
            int[] newTravelVectorXY = new int[2];
            List<int[]> travelLog = new List<int[]>();
            List<int[]> intersectionLog = new List<int[]>();

            //add starting position
            int[] origin = new int[] { 0, 0 };
            travelLog.Add(origin);

            //Hold user in a loop until a file name and path has been resolved
            while (waitingForFile)
            {
                Console.Clear();

                Console.WriteLine("Hit enter to confirm current filename, or enter a new filename");
                Console.Write("filename: {0}  >", defaultFileName);
                fileName = Console.ReadLine();
                Console.WriteLine("");

                //If the user hits enter on a blank line, keep default. Otherwise overwrite default
                if (string.IsNullOrEmpty(fileName))
                {
                    fileName = defaultFileName;
                }
                else
                {
                    defaultFileName = fileName;
                }

                Console.WriteLine("Enter the path to this file. Do not include the file itself");
                Console.Write("file path:  >");
                filePath = Console.ReadLine();
                Console.WriteLine("");

                //for usability, add a trailing to filepath slash if there is none
                //if path is null, the user needs to enter something
                try
                {
                    if (filePath.Substring(filePath.Length - 1) != "\\")
                    {
                        filePath += "\\";
                    }

                    try
                    {
                        StreamReader textFileReader = new StreamReader(filePath + fileName);
                        while (!textFileReader.EndOfStream)
                        {
                            string directions = textFileReader.ReadLine().ToString();

                            try
                            {
                                for (int i = 0; i < directions.Length; i++)
                                {

                                    char direction = Char.Parse(directions.Substring(i, 1));
                                    if (direction != 'F' && direction != 'L' && direction != 'R')
                                    {
                                        throw new Exception();
                                    }
                                    else
                                    {
                                        directionsList.Add(direction);
                                    }
                                }

                                Console.WriteLine("Prevent the logging of duplicate co-ordinates?");
                                Console.Write("Y/N  >");
                                logUnique = Console.ReadLine();
                                Console.WriteLine("");

                                if (logUnique.ToUpper() != "Y" & logUnique.ToUpper() != "N")
                                {
                                    Console.WriteLine("Please type either Y or N");
                                    Console.WriteLine("Press any key to try again");
                                    Console.ReadKey();
                                }
                                else
                                {
                                    waitingForFile = false;
                                }

                            }
                            catch
                            {
                                Console.WriteLine("Invalid directions in file. Valid directions consist of the characters 'F' 'L' 'R'. No spaces.");
                                Console.WriteLine("Press any key try again");
                                Console.ReadKey();
                            }
                        }
                    }
                    catch
                    {
                        Console.WriteLine("Could not find that file. Please check your path or filename");
                        Console.WriteLine("Press any key try again");
                        Console.ReadKey();
                    }

                }
                catch
                {
                    Console.WriteLine("Please enter a file path");
                    Console.WriteLine("Press any key try again");
                    Console.ReadKey();
                }
            }//end while (waitingForFile)

            //Loop through directions and output intersections
            foreach (char direction in directionsList)
            {
                try
                {
                    switch (direction)
                    {
                        case 'F':
                            for (int i = 0; i < travelLog.Count - 1; i++)
                            {
                                if (travelLog.ElementAt(i)[0] == currentXY[0] && travelLog.ElementAt(i)[1] == currentXY[1])
                                {
                                    int[] newIntersection = new int[] { currentXY[0], currentXY[1] };

                                    //log all intersections
                                    if (logUnique.ToUpper() == "N")
                                    {
                                        intersectionLog.Add(newIntersection);
                                    }
                                    //log unique co-ordinates
                                    else
                                    {
                                        bool duplicateFound = false;

                                        foreach (int[] intersection in intersectionLog)
                                        {
                                            if (intersection[0] == newIntersection[0] && intersection[1] == newIntersection[1])
                                            {
                                                duplicateFound = true;
                                            }
                                        }

                                        if (!duplicateFound)
                                        {
                                            intersectionLog.Add(newIntersection);
                                        }

                                    }

                                }
                            }

                            //add vector to position
                            currentXY[0] = currentXY[0] + travelVectorXY[0];
                            currentXY[1] = currentXY[1] + travelVectorXY[1];
                            int[] newXY = new int[] { currentXY[0], currentXY[1] };
                            travelLog.Add(newXY);


                            break;
                        case 'L':
                            //Derived from a Rotation Matrix operation where θ = π/2
                            newTravelVectorXY[0] = -1 * travelVectorXY[1];
                            newTravelVectorXY[1] = travelVectorXY[0];

                            travelVectorXY[0] = newTravelVectorXY[0];
                            travelVectorXY[1] = newTravelVectorXY[1];
                            break;
                        case 'R':
                            //Derived from a Rotation Matrix operation where θ = -π/2
                            newTravelVectorXY[0] = travelVectorXY[1];
                            newTravelVectorXY[1] = -1 * travelVectorXY[0];

                            travelVectorXY[0] = newTravelVectorXY[0];
                            travelVectorXY[1] = newTravelVectorXY[1];
                            break;
                        default:
                            //shouldn't happen. Placed here just in case.
                            throw new Exception();
                    }
                }
                catch
                {
                    Console.WriteLine("An error has occured during travel");
                }
            }//end foreach (direction in direction list)

            if (intersectionLog.Count > 0)
            {
                Console.WriteLine("The turtle has finished its journey, intersecting its path at the following{0}co-ordinates:",
                    logUnique.ToUpper() == "Y" ? " unique " : " ");
                foreach (int[] intersection in intersectionLog)
                {
                    Console.WriteLine("({0},{1})", intersection[0], intersection[1]);
                }
                Console.Write("Press any key to continue ...");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("The turtle has finished its journey, but did not cross its path even once.");
                Console.Write("Press any key to continue ...");
                Console.ReadKey();
            }

        }
    }
}
